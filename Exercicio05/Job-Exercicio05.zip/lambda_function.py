import requests
import mysql.connector
import json

import create_database
import mysql_create_table_csv
import mysql_create_table_api
import read_csv_file_mysql
import read_api_file_mysql
import read_api_file_mysql_trusted

import mysql_create_fato1
import dimcategoria
import diminstituicao
import dimperiodo
import dimtipo

import mysql_create_fato2
import dimservicos

import insert_fato1
import insert_fato2
    




def lambda_handler(event, context):
    
    create_database
    mysql_create_table_csv
    mysql_create_table_api
    read_csv_file_mysql
    read_api_file_mysql
    read_api_file_mysql_trusted
    
    mysql_create_fato1
    dimcategoria
    diminstituicao
    dimperiodo
    dimtipo

    mysql_create_fato2
    dimservicos

    insert_fato1
    insert_fato2
    

    
