import json
import requests
import mysql.connector


def create_database():

    conx = mysql.connector.connect(
      host="database-2.cvujcprqghrq.us-east-1.rds.amazonaws.com",
      user="admin",
      password="MinhaSenha01"
    )
    
    mycursor = conx.cursor()
    
    mycursor.execute("CREATE DATABASE IF NOT EXISTS engenhariadados;")
    
create_database()
