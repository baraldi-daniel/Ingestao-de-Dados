import mysql.connector

def insert_fato1():
  
  mydb = mysql.connector.connect(
    host="database-2.cvujcprqghrq.us-east-1.rds.amazonaws.com",
    user="admin",
    password="MinhaSenha01",
    database="engenhariadados"
  )
  

  mycursor = mydb.cursor()
  
  mycursor.execute("INSERT INTO fato1 (CHAVEPERIODO,CNPJ, QTDPROBLEMASREGULADOSPROCEDENTES) SELECT CONCAT(Ano,Trimestre),CNPJ,QuantidadeReclamacoesReguladasProcedentes FROM csv WHERE CNPJ!='';")
  
  mydb.commit()
  
  mydb.close()
    
insert_fato1()
 