import mysql.connector

def mysql_create_table_csv():
  
    mydb = mysql.connector.connect(
      host="database-2.cvujcprqghrq.us-east-1.rds.amazonaws.com",
      user="admin",
      password="MinhaSenha01",
      database="engenhariadados"
    )
  
    mycursor = mydb.cursor()
      
    mycursor.execute(
        '''CREATE TABLE IF NOT EXISTS apidadoscoletados (
           CNPJ VARCHAR(255),
           CodigoServico VARCHAR(255),
           Servico VARCHAR(255),
           Unidade VARCHAR(255),
           DataVigencia VARCHAR(255),
           ValorMaximo VARCHAR(255),
           TipoValor VARCHAR(255),
           Periodicidade VARCHAR(255));''')  
    
    mydb.close()
    
mysql_create_table_csv()
 