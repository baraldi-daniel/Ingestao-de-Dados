import mysql.connector
import json
import csv
import boto3

def mysql_create_fato2():
  
  mydb = mysql.connector.connect(
    host="database-2.cvujcprqghrq.us-east-1.rds.amazonaws.com",
    user="admin",
    password="MinhaSenha01",
    database="engenhariadados"
  )
  
  bucket_name = 'exercicio05'
  
  mycursor = mydb.cursor()
  
  mycursor.execute("CREATE TABLE fato2 (CNPJ VARCHAR(255), CodigoServico VARCHAR(255));")
  
  mycursor.execute("SELECT * FROM fato2")

  myresult = mycursor.fetchall()
  
  #print(myresult)
  
  with open('/tmp/fato2.csv', 'w') as f:
    mywriter = csv.writer(f, delimiter=',')
    mywriter.writerows(myresult)      

  s3_client = boto3.client('s3')
  with open('/tmp/' + 'fato2.csv') as file:
    object = file.read()
    s3_client.put_object(Body=object, Bucket=bucket_name, Key='analytics/fato2/fato2.csv', ContentType='text/csv', ContentEncoding='iso-8859-1')
  

    
mysql_create_fato2()
 