import mysql.connector

def insert_fato2():
  
  mydb = mysql.connector.connect(
    host="database-2.cvujcprqghrq.us-east-1.rds.amazonaws.com",
    user="admin",
    password="MinhaSenha01",
    database="engenhariadados"
  )
  

  mycursor = mydb.cursor()
  
  mycursor.execute("INSERT INTO fato2 (CNPJ, CodigoServico) SELECT CNPJ,CodigoServico FROM apidadoscoletados WHERE CNPJ!='' GROUP BY CNPJ, CodigoServico;")
  
  
  mydb.commit()
  
  mydb.close()
    
insert_fato2()
 