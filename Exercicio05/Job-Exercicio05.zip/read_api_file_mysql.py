import requests
import mysql.connector
import json
import csv
import boto3

#conn = sqlite3.connect('stage_database.db')  
  
#data = conn.execute("select CNPJ from csv"); 

def read_api_file_mysql():

    mydb = mysql.connector.connect(
      host="database-2.cvujcprqghrq.us-east-1.rds.amazonaws.com",
      user="admin",
      password="MinhaSenha01",
      database="engenhariadados"
    )
    
    bucket_name = 'exercicio05'
    
    mycursor = mydb.cursor()
    
    mycursor.execute("SELECT CNPJ FROM csv WHERE CNPJ!='' GROUP BY CNPJ")
    
    dados=mycursor.fetchall()
    
    #print(dados)
    
    #PessoaFisicaouJuridica = ['F','J']
    
    for cnpj in dados:
        #print(cnpj)
        if(str(cnpj[0]) != '' and str(cnpj[0]) != '0000000 '):
            
            url = f"https://olinda.bcb.gov.br/olinda/servico/Informes_ListaTarifasPorInstituicaoFinanceira/versao/v1/odata/" \
                f"ListaTarifasPorInstituicaoFinanceira(PessoaFisicaOuJuridica=@PessoaFisicaOuJuridica,CNPJ=@CNPJ)?@PessoaFisicaOuJuridica='F'" \
                f"&@CNPJ='{cnpj[0]}'&$format=json"
    
            r = requests.get(url = url, verify=False ,timeout=300)
            print(url)
            response = r.json()['value']
            
    
            for i in range(0,len(response)):
                CodigoServico = response[i]['CodigoServico']
                Servico = response[i]['Servico']
                Unidade =  response[i]['Unidade']
                DataVigencia = response[i]['DataVigencia']
                ValorMaximo = response[i]['ValorMaximo']
                TipoValor = response[i]['TipoValor']
                Periodicidade = response[i]['Periodicidade']
    
                query = f'INSERT INTO apidadoscoletados (' \
                f'CNPJ, CodigoServico, Servico, Unidade, DataVigencia,' \
                f'ValorMaximo, TipoValor, Periodicidade)' \
                f' VALUES (' \
                f'\'{cnpj[0]}\',' \
                f'\'{CodigoServico}\',' \
                f'\'{Servico}\',' \
                f'\'{Unidade}\',' \
                f'\'{DataVigencia}\',' \
                f'\'{ValorMaximo}\',' \
                f'\'{TipoValor}\',' \
                f'\'{Periodicidade}\'' \
                f');' 
    
                mycursor.execute(query);  
    
    mydb.commit()  
    
    
    mycursor.execute("SELECT * FROM apidadoscoletados")

    myresult = mycursor.fetchall()
  
    #print(myresult)
    
    with open('/tmp/data_api.csv', 'w') as f:
        mywriter = csv.writer(f, delimiter=',')
        mywriter.writerows(myresult)      

    s3_client = boto3.client('s3')
    with open('/tmp/' + 'data_api.csv') as file:
        object = file.read()
        s3_client.put_object(Body=object, Bucket=bucket_name, Key='raw/API/data_api.csv', ContentType='text/csv', ContentEncoding='iso-8859-1')
  

    
    
    mydb.close()
    
read_api_file_mysql()
