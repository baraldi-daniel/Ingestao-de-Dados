import mysql.connector
import json
import csv
import boto3

def diminstituicao():
  
  mydb = mysql.connector.connect(
    host="database-2.cvujcprqghrq.us-east-1.rds.amazonaws.com",
    user="admin",
    password="MinhaSenha01",
    database="engenhariadados"
  )
  
  bucket_name = 'exercicio05'
  
  mycursor = mydb.cursor()
  
  mycursor.execute("CREATE TABLE diminstituicao AS (SELECT CNPJ,InstituicaoFinanceira FROM csv WHERE CNPJ!='' GROUP BY CNPJ ORDER BY InstituicaoFinanceira);")
  
  
  #mycursor.execute("ALTER TABLE diminstituicao MODIFY COLUMN CNPJ INT;")
  
  mydb.commit()
  
  
  mycursor.execute("SELECT * FROM diminstituicao")

  myresult = mycursor.fetchall()
  
  print(myresult)
  
  with open('/tmp/diminstituicao.csv', 'w') as f:
    mywriter = csv.writer(f, delimiter=',')
    mywriter.writerows(myresult)      

  s3_client = boto3.client('s3')
  with open('/tmp/' + 'diminstituicao.csv') as file:
    object = file.read()
    s3_client.put_object(Body=object, Bucket=bucket_name, Key='analytics/fato1/diminstituicao.csv', ContentType='text/csv', ContentEncoding='iso-8859-1')
  
  
  
  mydb.close()
    
diminstituicao()
 