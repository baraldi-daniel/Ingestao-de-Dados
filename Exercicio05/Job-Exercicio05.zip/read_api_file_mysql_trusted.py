import requests
import mysql.connector
import json
import csv
import boto3



def read_api_file_mysql_trusted():

    mydb = mysql.connector.connect(
      host="database-2.cvujcprqghrq.us-east-1.rds.amazonaws.com",
      user="admin",
      password="MinhaSenha01",
      database="engenhariadados"
    )
    
    bucket_name = 'exercicio05'
    
    mycursor = mydb.cursor()
    
    mycursor.execute("SELECT * FROM apidadoscoletados WHERE CNPJ!=''")
    
    dados=mycursor.fetchall()
    
    #print(dados)
    
    
    with open('/tmp/data_api_trusted.csv', 'w') as f:
        mywriter = csv.writer(f, delimiter=',')
        mywriter.writerows(dados)      

    s3_client = boto3.client('s3')
    with open('/tmp/' + 'data_api_trusted.csv') as file:
        object = file.read()
        s3_client.put_object(Body=object, Bucket=bucket_name, Key='trusted/API/data_api_trusted.csv', ContentType='text/csv', ContentEncoding='iso-8859-1')
  

    
    
    mydb.close()
    
read_api_file_mysql_trusted()
