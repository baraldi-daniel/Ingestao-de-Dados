import mysql.connector
import json
import csv
import boto3

def dimtipo():
    
  mydb = mysql.connector.connect(
    host="database-2.cvujcprqghrq.us-east-1.rds.amazonaws.com",
    user="admin",
    password="MinhaSenha01",
    database="engenhariadados"
  )
  
  bucket_name = 'exercicio05'
  
  mycursor = mydb.cursor()
  
  mycursor.execute("CREATE TABLE dimtipo AS (SELECT CNPJ,Tipo FROM csv WHERE CNPJ!='' GROUP BY CNPJ);")
  
  #mycursor.execute("ALTER TABLE dimtipo MODIFY COLUMN CNPJ INT;")
  
  mydb.commit()
  
  
  mycursor.execute("SELECT * FROM dimtipo")

  myresult = mycursor.fetchall()
  
  #print(myresult)
  
  with open('/tmp/dimtipo.csv', 'w') as f:
    mywriter = csv.writer(f, delimiter=',')
    mywriter.writerows(myresult)      

  s3_client = boto3.client('s3')
  with open('/tmp/' + 'dimtipo.csv') as file:
    object = file.read()
    s3_client.put_object(Body=object, Bucket=bucket_name, Key='analytics/fato1/dimtipo.csv', ContentType='text/csv', ContentEncoding='iso-8859-1')
  
  mydb.close()
  
dimtipo()
 