import mysql.connector
import json
import csv
import boto3

def dimcategoria():
  
  mydb = mysql.connector.connect(
    host="database-2.cvujcprqghrq.us-east-1.rds.amazonaws.com",
    user="admin",
    password="MinhaSenha01",
    database="engenhariadados"
  )
  
  bucket_name = 'exercicio05'
  
  mycursor = mydb.cursor()
  
  mycursor.execute("CREATE TABLE dimcategoria AS (SELECT CNPJ,Categoria FROM csv WHERE CNPJ!='' GROUP BY CNPJ);")
  
  #mycursor.execute("ALTER TABLE dimcategoria MODIFY COLUMN CNPJ INT;")
  
  mydb.commit()
  
  mycursor.execute("SELECT * FROM dimcategoria")

  myresult = mycursor.fetchall()
  
  #print(myresult)
  
  with open('/tmp/dimcategoria.csv', 'w') as f:
    mywriter = csv.writer(f, delimiter=',')
    mywriter.writerows(myresult)      

  s3_client = boto3.client('s3')
  with open('/tmp/' + 'dimcategoria.csv') as file:
    object = file.read()
    s3_client.put_object(Body=object, Bucket=bucket_name, Key='analytics/fato1/dimcategoria.csv', ContentType='text/csv', ContentEncoding='iso-8859-1')
  
  
  
  mydb.close()
    
dimcategoria()
 