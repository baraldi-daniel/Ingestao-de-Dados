import mysql.connector 


def mysql_create_table_csv():



    conx = mysql.connector.connect(
      host="database-2.cvujcprqghrq.us-east-1.rds.amazonaws.com",
      user="admin",
      password="MinhaSenha01",
      database="engenhariadados"
    )
      
    mycursor = conx.cursor()
    

      
    mycursor.execute('''CREATE TABLE IF NOT EXISTS csv (
           Ano VARCHAR(255),
           Trimestre VARCHAR(255),
           Categoria VARCHAR(255),
           Tipo VARCHAR(255),
           CNPJ VARCHAR(255),
           InstituicaoFinanceira VARCHAR(255),
           Indice VARCHAR(255),
           QuantidadeReclamacoesReguladasProcedentes INT,
           QuantidadeReclamacoesReguladasOutras VARCHAR(255),
           QuantidadeReclamacoesNaoReguladas VARCHAR(255),
           QuantidadeTotalReclamacoes VARCHAR(255),
           QuantidadeTotalClientesCCSSCR VARCHAR(255),
           QuantidadeClientesCCS VARCHAR(255),
           QuantidadeClientesSCR VARCHAR(255));''')  
    
    
    conx.commit()  
    conx.close()
    
mysql_create_table_csv()


