import boto3
import csv
import mysql.connector

import requests

def read_csv_file_mysql():
  
  mydb = mysql.connector.connect(
    host="database-2.cvujcprqghrq.us-east-1.rds.amazonaws.com",
    user="admin",
    password="MinhaSenha01",
    database="engenhariadados"
  )
  
  mycursor = mydb.cursor()

  bucket_name = 'exercicio05'
  PREFIX = 'raw/CSV/Bancos+e+financeiras+-+Reclamacoes+e+quantidades+de+clientes+por+instituicao+financeira'
  

  s3 = boto3.resource('s3')
  bucket = s3.Bucket(bucket_name)
  
  prefix_objs = bucket.objects.filter(Prefix=PREFIX)

  
  s3client = boto3.client("s3")
  response = s3client.list_objects_v2(Bucket=bucket_name, Prefix =PREFIX)
  
  for id_key in range(len(response['Contents'])):
    key=response['Contents'][id_key]['Key']

    txt_file = s3.Object(bucket_name, key).get()['Body'].read().decode('iso-8859-1').splitlines()
    
    for id,line in enumerate(txt_file):
      if id==0:
        continue
      else:
        arr = line.split(";")
        if line[4]!="" or line[4]!=" ":
        #print(arr)
          if len(line[4])<8 and arr[4]!="":
            zeros_add=(8-len(arr[4]))*"0"
            final_cnpj=zeros_add+arr[4]
          #  print(line)
          else:
            final_cnpj=arr[4]
          
          query = f'INSERT INTO csv (' \
                          f'Ano, Trimestre, Categoria, Tipo, CNPJ,' \
                          f'InstituicaoFinanceira,' \
                          f'Indice,' \
                          f'QuantidadeReclamacoesReguladasProcedentes,' \
                          f'QuantidadeReclamacoesReguladasOutras,' \
                          f'QuantidadeReclamacoesNaoReguladas,' \
                          f'QuantidadeTotalReclamacoes,' \
                          f'QuantidadeTotalClientesCCSSCR,' \
                          f'QuantidadeClientesCCS,' \
                          f'QuantidadeClientesSCR) ' \
                          f'VALUES (' \
                          f'\'{arr[0]}\',' \
                          f'\'{arr[1]}\',' \
                          f'\'{arr[2]}\',' \
                          f'\'{arr[3]}\',' \
                          f'\'{final_cnpj}\',' \
                          f'\'{arr[5]}\',' \
                          f'\'{arr[6]}\',' \
                          f'\'{arr[7]}\',' \
                          f'\'{arr[8]}\',' \
                          f'\'{arr[9]}\',' \
                          f'\'{arr[10]}\',' \
                          f'\'{arr[11]}\',' \
                          f'\'{arr[12]}\',' \
                          f'\'{arr[13]}\'' \
                          f');'
      
          mycursor.execute(query)
                
    
  mydb.commit()  
  
  mycursor.execute("SELECT * FROM csv")

  myresult = mycursor.fetchall()
  
  #print(myresult)
  
  with open('/tmp/data_csv.csv', 'w') as f:
    mywriter = csv.writer(f, delimiter=',')
    mywriter.writerows(myresult)      

  s3_client = boto3.client('s3')
  with open('/tmp/' + 'data_csv.csv') as file:
    object = file.read()
    s3_client.put_object(Body=object, Bucket=bucket_name, Key='trusted/CSV/data_csv.csv', ContentType='text/csv', ContentEncoding='iso-8859-1')
  

    
  mydb.close()
  
read_csv_file_mysql()