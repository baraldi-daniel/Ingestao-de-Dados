from airflow import DAG
from airflow.operators.bash import BashOperator
from datetime import datetime
from datetime import datetime, timedelta
default_args = {'start_date': datetime(2022,1,1)}
with DAG('DAG_01', default_args=default_args, schedule_interval='@daily', catchup=False, dagrun_timeout=timedelta(minutes=60)) as dag:
    task_1 = BashOperator(task_id='task_1', bash_command='python /home/airflow/airflow/dags/create_database_mysql.py',dag=dag)
    task_2 = BashOperator(task_id='task_2', bash_command='python /home/airflow/airflow/dags/mysql_create_table_csv.py',dag=dag)
    task_3 = BashOperator(task_id='task_3', bash_command='python /home/airflow/airflow/dags/mysql_create_table_api.py',dag=dag)
    task_4 = BashOperator(task_id='task_4', bash_command='python /home/airflow/airflow/dags/read_csv_file_mysql.py',dag=dag)
    task_5 = BashOperator(task_id='task_5', bash_command='python /home/airflow/airflow/dags/read_api_data_mysql.py',dag=dag)
    task_6 = BashOperator(task_id='task_6', bash_command='cd /home/airflow/dbt; dbt run',dag=dag)

task_1 >> task_2 >> task_3 >> task_4 >> task_5 >> task_6