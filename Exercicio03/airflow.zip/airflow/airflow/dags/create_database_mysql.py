import mysql.connector

conx = mysql.connector.connect(
  host="database-id-mysql.cvujcprqghrq.us-east-1.rds.amazonaws.com",
  user="root",
  password="MinhaSenha01"
)

mycursor = conx.cursor()

mycursor.execute("CREATE DATABASE engenhariadados;")
